# Aanaristays Android APK source

This archive is the **Android-app edition** of the portal. Its entry page is `www/index.html`; it is separate from the browser HTML file in the GitHub Pages repository. The browser HTML is not replaced by this archive.

## Included
- A dedicated Android interface with a nested, collapsible left navigation sidebar; phone layouts use a slide-out drawer, while larger screens show a persistent sidebar
- Existing portal business rules and Google Apps Script endpoint
- Existing login/session protection, offline-first storage and synchronisation logic
- Capacitor 7 native file storage and sharing for Excel exports (plugin bridge bundles are copied into the APK at build time)
- Capacitor Printer native Android print dialog for invoices and quotations (includes Android's Save as PDF destination)
- Aanaristays app label and supplied launcher logo

## GitHub upload
1. Upload `Aanaristays_Android.html` and `Aanaristays_Android_Build_Source.zip` to the root of the same repository as the browser portal. Keep the existing browser HTML as the GitHub Pages entry point.
2. Create `.github/workflows/android.yml` and paste the supplied `android.yml` file contents.
3. Commit all three files.
4. Open GitHub Actions → **Build Aanaristays Android APK** → Run workflow.
5. Download the **Aanaristays-Android-APK** artifact from the successful run and install `app-debug.apk` on Android.

## Android navigation
- Dashboard is a direct navigation item. Reservations groups Booking Details, Quotations and Calendar. Administration groups the password-protected Master Data area.
- The sidebar drawer adapts to narrow phone screens; tablets and larger screens use a fixed side rail. The original browser HTML remains separate and unchanged.

## Export behaviour
Excel files are written to `Documents/Aanaristays/Exports/` and the Android share sheet is opened so the user can share or save a copy elsewhere. Print and Save PDF actions open Android's native print service; select **Save as PDF** there to create a PDF on the device.

## Important
- The Android APK is a separate native app installation and has its own device-local offline database/session identity. It uses the same Google Apps Script and cloud sheets as the browser portal.
- Only one authorised device/browser session can own a portal at a time, as enforced by the existing Apps Script session controls.
- Cloud synchronisation requires internet access; offline mode continues to use local device storage.
- The workflow builds a debug APK for testing. A Play Store release needs a signed release build.
- Third-party CDN assets in the original portal still require internet access unless separately bundled.
