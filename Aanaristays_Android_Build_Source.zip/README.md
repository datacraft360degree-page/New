# Aanaristays Android APK source

This archive contains the Android app wrapper, Capacitor configuration, native plugin dependencies and launcher assets. The separate repository-root file `Aanaristays_Android.html` is copied to `www/index.html` by the workflow. The browser HTML remains the GitHub Pages entry point and is not replaced.

## Included
- Mobile-first Android app interface, scaled to phone and tablet sizes
- Existing portal business rules and Google Apps Script endpoint
- Existing login/session protection, offline-first storage and synchronisation logic
- Capacitor 7 native file storage and sharing for Excel exports
- Capacitor Printer native Android print dialog for invoices and quotations (includes Android's Save as PDF destination)
- Aanaristays app label and supplied launcher logo

## GitHub upload
1. Upload `Aanaristays_Android.html` and `Aanaristays_Android_Build_Source.zip` to the root of the same repository as the browser portal. Keep the existing browser HTML as the GitHub Pages entry point.
2. Create `.github/workflows/android.yml` and paste the supplied `android.yml` file contents.
3. Commit all three files.
4. Open GitHub Actions → **Build Aanaristays Android APK** → Run workflow.
5. Download the **Aanaristays-Android-APK** artifact from the successful run and install `app-debug.apk` on Android.

## Export behaviour
Excel files are written to `Documents/Aanaristays/Exports/` and the Android share sheet is opened so the user can share or save a copy elsewhere. Print and Save PDF actions open Android's native print service; select **Save as PDF** there to create a PDF on the device.

## Important
- The Android APK is a separate native app installation and has its own device-local offline database/session identity. It uses the same Google Apps Script and cloud sheets as the browser portal.
- Only one authorised device/browser session can own a portal at a time, as enforced by the existing Apps Script session controls.
- Cloud synchronisation requires internet access; offline mode continues to use local device storage.
- The workflow builds a debug APK for testing. A Play Store release needs a signed release build.
- Third-party CDN assets in the original portal still require internet access unless separately bundled.
